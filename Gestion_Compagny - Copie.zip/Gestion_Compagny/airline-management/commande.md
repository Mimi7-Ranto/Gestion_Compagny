psql -U postgres -c "CREATE DATABASE company;"
.\mvnw.cmd spring-boot:run
ao am application.properties: mdp anle postgres solona.